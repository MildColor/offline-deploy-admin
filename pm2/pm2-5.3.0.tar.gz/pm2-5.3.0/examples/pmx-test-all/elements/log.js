
setInterval(function() {
  console.log('log');
  console.error('log');
}, 200);
