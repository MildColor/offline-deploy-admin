

setInterval(function() {
  console.log('out');
}, 1000);

setInterval(function() {
  console.error('err');
}, 1000);
