
To start tcp application in cluster mode:

```bash
$ pm2 start ecosystem.config.js
# OR
$ pm2 start tcp.js -i max
```
