setTimeout(() => {
  throw new Error('err')
}, 100)
