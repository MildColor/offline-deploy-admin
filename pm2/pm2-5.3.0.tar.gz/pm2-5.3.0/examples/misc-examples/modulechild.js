

console.log(module.parent);
