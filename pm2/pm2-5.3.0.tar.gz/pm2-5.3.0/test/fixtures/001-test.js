


setInterval(function() {
  console.log('log message from echo.js');
  console.error('err msg from echo.js');
}, 50);
