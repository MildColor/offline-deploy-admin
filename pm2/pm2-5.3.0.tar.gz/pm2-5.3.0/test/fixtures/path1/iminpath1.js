
console.log(process.cwd());
