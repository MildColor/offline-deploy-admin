export function test() {
  setInterval(() => console.log(`Hello es6 from pm2`), 1000);
}
