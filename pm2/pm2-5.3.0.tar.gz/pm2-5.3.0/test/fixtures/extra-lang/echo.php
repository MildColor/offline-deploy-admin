<?php
while(1)
    {
        print "PHP\n";
        error_log("ERROR");
        sleep(1);
    }
?>