
setInterval(function() {
  console.log('echo.js');
}, 5000);

setInterval(function() {
  console.error('echo.js-error');
}, 5000);
