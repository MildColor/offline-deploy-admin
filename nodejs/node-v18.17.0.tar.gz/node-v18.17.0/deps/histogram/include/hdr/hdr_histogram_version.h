/**
 * hdr_histogram_version.h
 * Written by Marco Ippolito, Michael Barker and released to the public domain,
 * as explained at http://creativecommons.org/publicdomain/zero/1.0/
 */

#ifndef HDR_HISTOGRAM_VERSION_H
#define HDR_HISTOGRAM_VERSION_H

#define HDR_HISTOGRAM_VERSION "0.11.8"

#endif  // HDR_HISTOGRAM_VERSION_H
